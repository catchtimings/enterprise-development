﻿namespace FoodDelivery.Domain.Entities;

/// <summary>
/// Блюдо ресторана
/// </summary>
public class Dish
{
    /// <summary>
    /// Идентификатор блюда
    /// </summary>
    public required int Id { get; set; }

    /// <summary>
    /// Название блюда
    /// </summary>
    public required string Name { get; set; }

    /// <summary>
    /// Вес блюда в граммах
    /// </summary>
    public int Weight { get; set; }

    /// <summary>
    /// Цена блюда в рублях
    /// </summary>
    public decimal Price { get; set; }

    /// <summary>
    /// Идентификатор категории блюда
    /// </summary>
    public required int CategoryId { get; set; }

    /// <summary>
    /// Категория блюда
    /// </summary>
    public DishCategory? Category { get; set; }
}